<?php
	$dbUser = 'localhost';
	$dbHost = 'root';
	$dbPass = '';
	$dbName = 'blog_crud';

	$db = mysqli_connect($dbUser, $dbHost, $dbPass, $dbName);
?>